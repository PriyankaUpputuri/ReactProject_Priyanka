import React, { Component } from 'react';
	
	class Cart extends Component {
	
	  render() {
	    return (
	      <div className="container">
	        <div className="jumbotron py-3 my-4 ">
	          <p className="display-4 text-center mb-0">View Cart</p>
	        </div>
	      </div>
	    );
	  }
	}
	
	export default Cart;
